<?php
class Other
{
    public function alert($msg)
    {
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }
}
