<script src="/Web2/admin/common/Other.js"></script>
<script src="/Web2/admin/common/InputTester.js"></script>
<!-- <script src="/Web2/admin/public/resource/jquery-3.6.0.min.js" type="text/javascript"></script>
<script src="/Web2/admin/public/resource/bootstrap-5.0.0-beta3-dist/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="/Web2/admin/public/resource/bootstrap-5.0.0-beta3-dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/Web2/admin/public/resource/fontawesome-free-5.15.3-web/css/all.min.css" /> -->
<script src="../bootstrap/js/jquery.min.js"></script>
<script src="../bootstrap/js/bootstrap.min.js"></script>
<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../fontawesome/css/all.min.css">
<link rel="shortcut icon" href="#">
<title>Quản lý cửa hàng bánh MUN</title>
<?php require_once 'app/index.php' ?>